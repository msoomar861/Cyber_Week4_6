# Ethical Hacking Report

Tools Used:
- Kali Linux
- SQLMap
- Burp Suite

Vulnerabilities Identified:
- SQL Injection
- CSRF

Fixes Applied:
- Prepared Statements
- CSRF Token Implementation

Result:
All critical vulnerabilities were fixed successfully.